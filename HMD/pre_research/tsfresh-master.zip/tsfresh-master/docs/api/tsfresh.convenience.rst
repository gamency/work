convenience
===========

.. automodule:: tsfresh.convenience
    :members:
    :undoc-members:
    :show-inheritance:

relevant_extraction module
--------------------------

.. automodule:: tsfresh.convenience.relevant_extraction
    :members:
    :undoc-members:
    :show-inheritance:


