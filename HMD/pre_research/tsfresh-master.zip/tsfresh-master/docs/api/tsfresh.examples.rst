examples
========

.. automodule:: tsfresh.examples
    :members:
    :undoc-members:
    :show-inheritance:


robot_execution_failures
------------------------

.. automodule:: tsfresh.examples.robot_execution_failures
    :members:
    :undoc-members:
    :show-inheritance:


har_dataset
-----------

.. automodule:: tsfresh.examples.har_dataset
    :members:
    :undoc-members:
    :show-inheritance:
