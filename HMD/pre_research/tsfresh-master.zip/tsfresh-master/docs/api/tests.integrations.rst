tests.integrations package
==========================

Submodules
----------

tests.integrations.test_full_pipeline module
--------------------------------------------

.. automodule:: tests.integrations.test_full_pipeline
    :members:
    :undoc-members:
    :show-inheritance:

tests.integrations.test_notebooks module
----------------------------------------

.. automodule:: tests.integrations.test_notebooks
    :members:
    :undoc-members:
    :show-inheritance:

tests.integrations.test_relevant_feature_extraction module
----------------------------------------------------------

.. automodule:: tests.integrations.test_relevant_feature_extraction
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: tests.integrations
    :members:
    :undoc-members:
    :show-inheritance:
