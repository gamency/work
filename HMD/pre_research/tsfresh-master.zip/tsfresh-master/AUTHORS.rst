

Authors
==========


Core Development Team
---------------------

- Maximilian Christ (`maximilianchrist.com <http://maximilianchrist.com>`_, `max.christ@me.com <max.christ@me.com>`_)
- Nils Braun  (`nilslennartbraun@gmail.com <nilslennartbraun@gmail.com>`_)
- Julius Neuffer (`julius.neuffer@blue-yonder.com <julius.neuffer@blue-yonder.com>`_)

Contributions
-------------
- Andreas W. Kempa-Liehr
- Markus Frey
- Niklas Haas
- earthgecko
- Moritz Gelb
- Thibault de Boissiere
- Brian Sang
- Stephan Müller
- Vin Tang
- Chris Chow
- Ezekiel Kruglick
- Timo Klerx
- Gregor Koehler
- Matúš Tomlein
- Florian Aspart
- Sergey Shepelev
- Justin White
- J. Kleint
