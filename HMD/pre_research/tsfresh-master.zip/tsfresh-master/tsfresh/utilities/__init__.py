"""
This :mod:`~tsfresh.utilities` submodule contains several utility functions.
Those should only be used internally inside tsfresh.
"""