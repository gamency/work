# -*- encoding:utf-8 -*-
from model_info import *
import numpy as np
import pickle
import pandas as pd
import datetime
import sys
from sklearn.externals import joblib
import os
from model_pkls import *
from feature_infos import *
from model_info import *


# short_long_name_dict = {short_name: long_name, ...}

reload(sys)
sys.setdefaultencoding('utf8')

filepath = os.path.split(os.path.realpath(__file__))[0]
sys.path.append(filepath)
tp_mh_clf = joblib.load(filepath + '/dt_TPMH.dot')


def feature_name_trans(params):
    name_dics = {'idNumber':'idNumber',
                 'ILZZ00000000':'uid_black',
                 'ILZZ01000000':'uid_grey',
                 'accountMobile':'accountMobile',
                 'mobile_address_province': 'mob_province_all_all_all',
                 'ILZZ00000001':'mob_black',
                 'ILZZ01000001':'mob_grey'
                 }

    params_new = dict()
    for k, v in params.items():

        if k in ['ILZZ00000000', 'ILZZ01000000', 'ILZZ00000001', 'ILZZ01000001', 'accountMobile']: continue
        elif k == 'idNumber':
            params_new['uid_province_all_all_all'] = IdNumToAreaNum.get(v[0:2], -1)
        elif k == 'mobile_address_province': params_new['mob_province_all_all_all'] = AreaCityToNum.get(v, -1)
        else: params_new[short_long_dict[k]] = try_float(v)

    params_new['black'] = params['ILZZ00000000'] + params['ILZZ00000001']
    params_new['grey'] = params['ILZZ01000000'] + params['ILZZ01000001']
    params_new = get_new_features(params_new)
    return params_new


def get_new_features(params):
    params['m_freq_weekday2_Loan_IFinanceWeb_Unconsumerfinance_180day_new'] = cal_new_feas(params['m_freq_weekday2_Loan_IFinanceWeb_180day'], params['m_freq_weekday2_Loan_Unconsumerfinance_180day'])
    params['i_freq_weekend2_Loan_IFinanceWeb_Unconsumerfinance_365day_new'] =cal_new_feas(params['i_freq_weekend2_Loan_IFinanceWeb_365day'], params['i_freq_weekend2_Loan_Unconsumerfinance_365day'])
    params['m_cnt_partner2_Loan_Unconsumerfinance_Imbank_365day_new'] = cal_new_feas(params['m_cnt_partner2_Loan_Unconsumerfinance_365day'], params['m_cnt_partner2_Loan_Imbank_365day'])
    params['m_mean_cnt_partner_daily2_Loan_Microloan_Consumerfinance_365day_new'] = cal_new_feas(params['m_mean_cnt_partner_daily2_Loan_Microloan_365day'], params['m_mean_cnt_partner_daily2_Loan_Consumerfinance_365day'])
    return params



def cal_new_feas(x, y):
    if x == -1: return -1
    if y in [-1, 0]: return -1
    return round(x * 1. / y, 2)


def try_float(x):
    try:
        v = float(x)
        if v == -1111: return -1
        return v
    except:
        return -1


def adjust_black_grey(score, params):
    black = params['black']
    grey = params['grey']
    if black > 0: # 当命中黑名单时,需要确保低于20%
        if score > black_score:
            score -= 90 * black
            if score > black_score: # 当命中黑名单时,减分后高于20%
                if grey > 0: score -= 60 * grey# 当命中灰名单时,再减分
                if score > black_score: score = black_score # 当高于20%, 截断为20%
    else:
        if grey > 0: # 当不命中黑名单,命中灰名单时,确保低于50%
            if score > grey_score: score -= 60 * grey
            #if score > grey_score: score = grey_score
    score = score_cut(score)
    return score


# assgin woe
def assgin_woe(stats):
    value_woe = {}
    for f, woes in woe_dict.items():
        x = stats.get(f, -1)
        try: x = float(x)
        except: x = x
        if f in nominal_value_dict: x = float(nominal_value_dict[f].get(x, -1))
        for key, woe in woes:
            if eval(key): value_woe[f] = woe
        if f not in value_woe: value_woe[f] = none_check[f]
    return value_woe


def cal_raw_score(params):
    woe = assgin_woe(params)
    woe['intercept'] = 1
    score = 600 - 200 / np.log(2) * sum([woe[k] * v for k, v in coef_dict.items()])
    if score < min_score: score = min_score
    if score > max_score: score = max_score
    a = 600. / (max_score - min_score)
    b = 300 - a * min_score
    raw_score = int(score * a + b)
    return raw_score


def thirdparty_mohe_raw_score(params):
    raw_score = cal_raw_score(params)
    p1 = [params[k] for k in tp_mh_list if k != 'score']
    if set(p1) == {-1}: return raw_score
    param = [raw_score] + p1
    df = pd.DataFrame(param).T
    df.columns = tp_mh_list
    p = tp_mh_clf.predict_proba(df)[0][1]
    score = int(600 - 200 / np.log(2) * np.log(p * 1. / (1 - p)))
    if score > tp_mh_max_score: score = tp_mh_max_score
    if score < tp_mh_min_score: score = tp_mh_min_score
    a = 600. / (tp_mh_max_score - tp_mh_min_score)
    b = 300 - a * tp_mh_min_score
    score = int(score * a + b)
    score = sjmh_adjust_by_black(params, score)
    return score


def score_cut(score):
    score = int(score)
    if score > 900: score = 900
    if score < 300: score = 300
    return score


def sjmh_adjust_by_black(params, score):
    black_minis = [
                     ('black_top10_contact_creditcrack_count_ratio', 200),
                     ('black_top10_contact_total_count_ratio', 180),
                     ('black_top10_contact_carloan_blacklist_count_ratio', 150),
                     ('black_top10_contact_studentloans_overdue_count_ratio', 120),
                     ('black_top10_contact_paymentfraud_count_ratio', 100),
                     ('black_top10_contact_over2_count_ratio', 80),
                     ('black_top10_contact_fakemobile_count_ratio', 60)
                  ]
    for i, s0 in black_minis:
        var = params.get(i, 0.)
        if var > 0: score -= s0 * float(var)
    return score_cut(score)


def handle(params):
    params = feature_name_trans(params)
    score = thirdparty_mohe_raw_score(params)
    score_adjust = adjust_black_grey(score, params)
    return {'micro_confin_score': score_adjust}





