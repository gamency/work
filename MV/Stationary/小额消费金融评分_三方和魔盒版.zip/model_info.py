

woe_dict = {'i_freq_record2_Loan_P2pweb_365day': [(' x >= 80.0', -2.2), ('33.0 <= x < 80.0', -1.2149), ('8.0 <= x< 33.0', -0.4861), ('2.0 <= x < 8.0', 0.2337), ('0.0 <= x < 2.0', 1.2306)], 'uid_province_all_all_all': [(' x >= 17', -0.1455), ('0 <= x < 17', 0.1264)], 'm_freq_day2_Register_all_180day': [(' x >= 5.0', -0.7134), ('0.0 <= x < 5.0', 0.55)], 'm_mean_cnt_partner_daily2_Loan_Microloan_Consumerfinance_365day_new': [(' x >= 0.5', -1.6433), ('0.0 <= x < 0.5', 0.0158), ('x == -1.0', 0.5918)], 'm_cnt_partner2_Loan_Unconsumerfinance_Imbank_365day_new': [('0.0 <= x < 0.5', -0.9047), ('x == -1.0', 0.6625), (' x>= 0.5', 0.9169)], 'i_cnt_accountemail2_all_all_180day': [(' x >= 2.0', -1.4117), ('1.0 <= x < 2.0', -0.5903), ('0.0 <= x < 1.0', 1.0566)], 'mob_province_all_all_all': [(' x >= 26', -0.3265), ('25 <= x < 26', -0.2113), ('21 <= x < 25', -0.1284), ('17 <= x < 21', -0.0369), ('0 <= x < 17', 0.1002), ('x == -1.0', 0.6869)], 'i_mean_length_event2_Loan_all_180day': [('0.0 <=x < 2.6327', -0.6359), ('2.6327 <= x < 3.2239', -0.2311), ('3.2239 <= x < 7.3626', 0.1643), ('7.3626 <= x < 17.1418', 0.5898), (' x >= 17.1418', 0.9746), ('x == -1.0', 1.2865)], 'i_mean_freq_record_daily2_Loan_finance_180day': [(' x >= 3.0', -0.3887), ('0.0 <= x < 3.0', 0.5855)], 'i_freq_weekend2_Loan_IFinanceWeb_Unconsumerfinance_365day_new': [(' x >= 0.01', -1.9372), ('0.0 <= x < 0.01', -0.0959), ('x == -1.0', 0.5745)], 'm_freq_weekday2_Loan_IFinanceWeb_Unconsumerfinance_180day_new': [(' x >= 0.01', -1.8056), ('0.0 <= x < 0.01', 0.2472), ('x == -1.0', 0.3923)], 'm_cnt_indtwo2_Register_all_180day': [(' x >= 4.0', -1.793), ('3.0 <= x < 4.0', -1.1141), ('2.0 <= x < 3.0', -0.3806), ('1.0 <= x < 2.0', 0.4606), ('0.0 <= x < 1.0', 0.6572)], 'm_length_first_last2_Login_all_365day': [(' x >= 275.2717', -1.2847), ('62.0882 <= x < 275.2717', -0.9633), ('23.7545 <= x < 62.0882', -0.6606), ('0.0001 <= x < 23.7545', -0.2412), ('0.0 <= x < 0.0001', 0.0626), ('x == -1.0', 0.618)], 'i_length_last2_Loan_finance_180day': [('0.0 <= x < 5.73', -0.6601), (' x >= 5.73', 0.4908), ('x == -1.0', 1.3254)]}



none_check = {'i_freq_record2_Loan_P2pweb_365day': 1.2306202856440573, 'uid_province_all_all_all': 0.12644170827626461, 'm_freq_day2_Register_all_180day': 0.5499779833836439, 'm_mean_cnt_partner_daily2_Loan_Microloan_Consumerfinance_365day_new': 0.5918, 'm_cnt_partner2_Loan_Unconsumerfinance_Imbank_365day_new': 0.6625, 'i_cnt_accountemail2_all_all_180day': 1.0565984168446627, 'mob_province_all_all_all': 0.6869, 'i_mean_length_event2_Loan_all_180day': 1.2865, 'i_mean_freq_record_daily2_Loan_finance_180day': 0.58553419958425645, 'i_freq_weekend2_Loan_IFinanceWeb_Unconsumerfinance_365day_new': 0.5745, 'm_freq_weekday2_Loan_IFinanceWeb_Unconsumerfinance_180day_new': 0.3923, 'm_cnt_indtwo2_Register_all_180day': 0.65720156725289569, 'm_length_first_last2_Login_all_365day': 0.618, 'i_length_last2_Loan_finance_180day': 1.3254}

nominal_value_dict = {'mob_province_all_all_all': {3075.0: 28, 2565.0: 25, 786.0: 14, 1155.0: 29, 30.0: 6, 2720.0: 26, 679.0: 22, 425.0: 5, 2607.0: 24, 1972.0: 16, 1973.0: 19, 2889.0: 15, 2236.0: 20, 844.0: 3, 1739.0: 18, 1740.0: 8, 1870.0: 12, 592.0: 21, 2129.0: 13, 212.0: 27, 1888.0: 23, 2539.0: 0, 2941.0: 9, 880.0: 4, 1011.0: 7, 1140.0: 11, 376.0: 17, 1017.0: 2, 1789.0: 10, 1790.0: 1}, 'uid_province_all_all_all': {3075.0: 29, 2565.0: 23, 786.0: 16, 1155.0: 30, 30.0: 7, 2720.0: 28, 679.0: 21, 425.0: 18, 2607.0: 24, 1972.0: 14, 1973.0: 15, 2889.0: 13, 2236.0: 22, 1400.0: 0, 844.0: 4, 1739.0: 20, 1740.0: 10, 1870.0: 17, 592.0: 25, 2129.0: 12, 212.0: 27, 1888.0: 26, 2539.0: 2, 2941.0: 8, 880.0: 5, 1011.0: 6, 1140.0: 11, 376.0: 19, 1017.0: 3, 1789.0: 9, 1790.0: 1}}

coef_dict = {'m_cnt_indtwo2_Register_all_180day': -0.033, 'i_freq_record2_Loan_P2pweb_365day': -0.6344, 'uid_province_all_all_all': -0.204, 'm_freq_day2_Register_all_180day': -0.0243, 'm_mean_cnt_partner_daily2_Loan_Microloan_Consumerfinance_365day_new': -0.0516, 'm_cnt_partner2_Loan_Unconsumerfinance_Imbank_365day_new': -0.0577, 'mob_province_all_all_all': -0.7697, 'i_mean_length_event2_Loan_all_180day': -0.04, 'intercept': -3.0787, 'i_mean_freq_record_daily2_Loan_finance_180day': -0.245, 'i_freq_weekend2_Loan_IFinanceWeb_Unconsumerfinance_365day_new': -0.0704, 'm_freq_weekday2_Loan_IFinanceWeb_Unconsumerfinance_180day_new': -0.1592, 'i_length_last2_Loan_finance_180day': -0.1531, 'm_length_first_last2_Login_all_365day': -0.0564, 'i_cnt_accountemail2_all_all_180day': -0.2258}

min_score = 643

max_score = 2131

black_score = 529

grey_score = 756

tp_list = ['score', 'consume', 'asset']

mh_list = ['score', 'uid_mh_yys_all_contact_stats_contact_count_passive_3month', 'uid_mh_yys_active_silence_stats_silence_day_0call_3month', 'uid_mh_yys_active_silence_stats_max_continue_active_day_1call_6month', 'uid_mh_yys_all_contact_stats_contact_count_mutual_6month']

tp_mh_list = [ 'score', 'consume', 'asset','uid_mh_yys_active_silence_stats_silence_day_0call_3month', 'uid_mh_yys_all_contact_detail_call_count_active_6month_mean', 'uid_mh_yys_all_contact_stats_contact_count_1month', 'uid_mh_yys_all_contact_stats_contact_count_mutual_6month', 'uid_mh_yys_all_contact_stats_contact_count_passive_3month']



mh_min_score = 624

mh_max_score = 2014

tp_min_score = 628

tp_max_score = 2017

tp_mh_min_score = 334

tp_mh_max_score = 2084

