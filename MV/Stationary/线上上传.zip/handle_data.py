# -*- coding: utf-8 -*-
from X_Engine.master_lightsaber import lightsaber
import pickle
import pandas as pd
import os
import demjson
import json

file_path = os.path.split(os.path.realpath(__file__))[0]

JEDI1 = pickle.load(open(file_path + os.sep + "/Model/201801231141_bio_stage1rfpc.sav", 'r'))
JEDI2 = pickle.load(open(file_path + os.sep + "/Model/20180191134_bio_stage2xgpc.sav", 'r'))


def handle(params):
    # event_info = json.loads(params)
    event_behavior_data_str = params.get("event_info")
    #print type(event_behavior_data_str)
    true_info_str = params.get("true_info")
    #print type(true_info_str)
    # true_info = json.loads(true_info_str)
    true_info= demjson.decode(true_info_str)
    #print(event_behavior_data_str) 
    #event_behavior_data = json.loads(event_behavior_data_str)
    event_behavior_data = demjson.decode(event_behavior_data_str)
    
    # event_behavior_data = params.get("event_info")
    # true_info = params.get("true_info")
    
    #event_behavior_data = json.loads(json.dumps(event_behavior_data_str))

    data = pd.DataFrame(event_behavior_data)

    de = 0.6
    if true_info["scenario"] == 0:
        JEDI = JEDI1
    elif true_info["scenario"] == 1:
        JEDI = JEDI2
    else:
        return {"Bot": str(de)}
    
    result = lightsaber(data, JEDI, true_info)
    
    print(result)

    return {"Bot": str(result)}

if __name__ == "__main__":
    # params =  {"event_info": { "Time": [1515639896196, 1238912], "event_type": [0, 1], "op_x": [681, 684],   "op_y": [538,  549],  "Action": ["_", "_"], "slidebarleft_x":[529.0, 530.0], "slidebarleft_y": [457.5, 458.8], "slidebarright_x": [565.0, 678], "slidebarright_y": [493.5,499] }}  
    params =  '{"event_info": { "Time": [1515639896196, 1515639896296], "event_type": [0, 1], "op_x": [681, 684],   "op_y": [538,  549],  "Action": ["_", "_"]}, "true_info": {"correct_x": 595.0, "correct_y": 302.5, "slidebarleft_x": 529.0, "slidebarleft_y": 457.5, "slidebarright_x": 565.0,"slidebarright_y": 493.5, "scenario": 1, "terminal": 0}}'
    params = {"event_info": { "Time": [1515639896196, 1515639896296], "event_type": [0, 1], "op_x": [681, 684],   "op_y": [538,  549],  "Action": ["_", "_"]}, "true_info": {"correct_x": 595.0, "correct_y": 302.5, "slidebarleft_x": 529.0, "slidebarleft_y": 457.5, "slidebarright_x": 565.0, "slidebarright_y": 493.5, "scenario": 0, "terminal": 0}}
    # params = {"event_info":[{"Time":1515639896196,  "event_type":0, "op_x":681, "op_y":538,  "Action":"_",  "correct_x":595.0, "correct_y":302.5, "slidebarleft_x":529.0, "slidebarleft_y":457.5, "slidebarright_x":565.0, "slidebarright_y":493.5},  {"Time":1515639896196,  "event_type":0, "op_x": 681, "op_y": 538,  "Action": "_", "correct_x":595.0, "correct_y":302.5, "slidebarleft_x":529.0, "slidebarleft_y":457.5, "slidebarright_x":565.0, "slidebarright_y":493.5}]}
    # params = {"event_info": [{"Time": 1515639896196, "event_type": 0, "op_x": 681, "op_y": 538, "Action": "_", },{"Time": 1515639896196, "event_type": 0, "op_x": 681, "op_y": 538, "Action": "_"}], "true_info": [{"correct_x": 595.0, "correct_y": 302.5, "slidebarleft_x": 529.0, "slidebarleft_y": 457.5, "slidebarright_x": 565.0,"slidebarright_y": 493.5}]}
    handle(params)