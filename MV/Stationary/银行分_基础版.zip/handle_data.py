# -*- encoding:utf-8 -*-
import sys
import numpy as np


reload(sys)
sys.setdefaultencoding('utf8')


# numFactorUid = {'FirstLoanInBank':'ZZZZ0005750','province':'ZZZZ0005760','max_cnt_calday_Loan_Imbank_30_90day':'ZZZZ0005770','cnt_partner_all_Imbank_180_365day':'ZZZZ0005780','isroot_all_all_180day':'ZZZZ0005790','ratio_cnt_partner_Loan_Bank_30day':'ZZZZ0005800','max_length_calday_diffpartner_all_P2pweb_365day':'ZZZZ0005810','BlackBefore':'ZZZZ0005820','gender':'ZZZZ0005830'}
# numFactorMob = {'FirstLoanInBank':'ZZZZ0006081','province':'ZZZZ0006091','ratio_freq_weekday_all_P2pweb_365day':'ZZZZ0006101','max_length_calday_diffpartner_Loan_Imbank_365day':'ZZZZ0006111','ratio_freq_record_all_P2pweb_60day':'ZZZZ0006121','mean_length_time_Loan_IFinanceWeb_180day':'ZZZZ0006131','mean_length_time_Loan_Insurance_180day':'ZZZZ0006141','cnt_accountemail_all_all_180day':'ZZZZ0006151','ratio_freq_policy_Accept_all_all_365day':'ZZZZ0006161','ratio_freq_record_Loan_con_90day':'ZZZZ0006171','ratio_cnt_partner_all_Imbank_30day':'ZZZZ0006181','BlackBefore':'ZZZZ0006191'}
# coefDict_uid = {'intercept': -3.0676230290203503, 'FirstLoanInBank': -0.10506855261595828, 'province': -0.11831697481111125, 'max_cnt_calday_Loan_Imbank_30_90day': -0.10316132933044499, 'isroot_all_all_180day': -0.081962868551776105, 'gender': -0.22260762358865613, 'ratio_cnt_partner_Loan_Bank_30day': -0.17279445804382654, 'BlackBefore': -0.59302187387427163, 'max_length_calday_diffpartner_all_P2pweb_365day': -0.69598723302672749, 'cnt_partner_all_Imbank_180_365day': -0.052468902190536792}
# coefDict_mob = {'intercept': -2.7398611522807905, 'province': -0.15978137157874359, 'FirstLoanInBank': -0.03274166140246465, 'ratio_freq_weekday_all_P2pweb_365day': -0.08849453353029052, 'max_length_calday_diffpartner_Loan_Imbank_365day': -0.36861839591865514, 'ratio_freq_record_all_P2pweb_60day': -0.1485522521617286, 'mean_length_time_Loan_IFinanceWeb_180day': -0.010972392205888375, 'cnt_accountemail_all_all_180day': -0.15418415934393556, 'mean_length_time_Loan_Insurance_180day': -0.14589749259633997, 'ratio_freq_policy_Accept_all_all_365day': -0.31413295341790787, 'BlackBefore': -0.62417999022475801, 'ratio_freq_record_Loan_con_90day': -0.059014409473392981, 'ratio_cnt_partner_all_Imbank_30day': -0.043984489110466277}
# woeDict_uid = {'FirstLoanInBank': {(1.0, 1.0): 0.0926, (2.0, 2.0): -0.3924}, 'province': {(42, 48): -0.4706, (30, 41): -0.2755, (0, 18): 1.2638, (19, 25): 0.1998, (-1, -1): -0.2755, (26, 29): -0.1256}, 'max_cnt_calday_Loan_Imbank_30_90day': {(0.0, 0.0): 0.873, (2.0, 2.0): -0.8491, (-2.0, -2.0): 0.258, (-1.0, -1.0): 1.3002, (1.0, 1.0): -0.6117, (3.0, 46.0): -0.8832}, 'isroot_all_all_180day': {(0.0, 0.0): -1.0225, (1.0, 1.0): -1.2475, (-1.0, -1.0): 0.3929}, 'gender': {(0.0, 0.0): -0.159, (1.0, 1.0): 0.5342}, 'ratio_cnt_partner_Loan_Bank_30day': {(0.23, 0.75): -0.1754, (1.0, 1.0): 1.526, (-2.0, -2.0): 0.2393, (0.0, 0.22): -0.7599, (-1.0, -1.0): 1.4024}, 'BlackBefore': {(0.0, 0.0): 0.2219, (1.0, 1.0): -2.139}, 'max_length_calday_diffpartner_all_P2pweb_365day': {(17.0, 82.0): -0.7237, (0.0, 0.0): 1.1245, (-3.0, -3.0): 0.3228, (1.0, 16.0): -0.3616, (-1.0, -1.0): 2.2894, (83.0, 298.0): -1.097, (299.0, 365.0): -1.4782}, 'cnt_partner_all_Imbank_180_365day': {(6.0, 50.0): -1.5322, (2.0, 2.0): -0.707, (0.0, 0.0): 0.4381, (-1.0, -1.0): 0.5999, (1.0, 1.0): -0.2999, (3.0, 5.0): -1.0713}}
# woeDict_mob = {'province': {(22.0, 25.0): 0.0314, (26.0, 27.0): 0.5151, (9.0, 21.0): -0.2101, (28.0, 31.0): 0.7278, (-1, -1): 0.0314, (0.0, 8.0): -0.4816}, 'FirstLoanInBank': {(1.0, 1.0): 0.1337, (2.0, 2.0): -0.7445}, 'max_length_calday_diffpartner_Loan_Imbank_365day': {(0.0, 0.0): 1.0771, (-3.0, -3.0): 0.614, (298.0, 365.0): -1.721, (-2.0, -2.0): 1.9759, (148.0, 297.0): -1.2815, (-1.0, -1.0): 1.769, (64.0, 147.0): -0.9734, (1.0, 63.0): -0.7087}, 'ratio_freq_record_all_P2pweb_60day': {(-1.0, -1.0): 1.4474, (0.51, 1.0): -1.1741, (0.0, 0.09): 0.9168, (0.1, 0.5): -1.0421}, 'mean_length_time_Loan_IFinanceWeb_180day': {(0.0, 0.0): -0.6765, (45.01, 60.0): -1.5661, (-1.0, -1.0): 1.6853, (60.01, 90.0): -1.4455, (-2.0, -2.0): 1.8268, (0.01, 45.0): -2.1138}, 'cnt_accountemail_all_all_180day': {(3.0, 13.0): -1.9534, (2.0, 2.0): -1.4633, (1.0, 1.0): -0.7112, (0.0, 0.0): 0.6939, (-1.0, -1.0): 1.6853}, 'mean_length_time_Loan_Insurance_180day': {(-2.0, -2.0): 1.8268, (45.0, 90.0): -1.4062, (-1.0, -1.0): 1.6853, (0.0, 36.0): -0.7236}, 'ratio_freq_policy_Accept_all_all_365day': {(0.3, 0.31): -0.883, (0.0, 0.29): -1.3235, (-1.0, -1.0): 1.769, (0.33, 0.33): 1.2349, (0.32, 0.32): -0.3467}, 'ratio_freq_weekday_all_P2pweb_365day': {(0.5, 1): -0.9477, (0.0, 0.0): 1.4447, (0.01, 0.49): -0.7976, (-1.0, -1.0): 1.769}, 'BlackBefore': {(0.0, 0.0): 0.2143, (1.0, 1.0): -2.4193}, 'ratio_freq_record_Loan_con_90day': {(-2.0, -2.0): 1.6322, (0.5, 0.66): -0.1656, (0.86, 1.0): 0.771, (-1.0, -1.0): 1.5518, (0.0, 0.32): -1.0574, (0.67, 0.85): 0.2106, (0.33, 0.49): -0.7527}, 'ratio_cnt_partner_all_Imbank_30day': {(0.68, 1.0): -1.0168, (0.56, 0.67): -0.6068, (0.33, 0.55): -0.049, (0.0, 0.29): 1.341, (-1.0, -1.0): 1.2334}}

coefDict_mob = {'intercept': -2.7398611522807905,'ZZZZ0006081': -0.03274166140246465,'ZZZZ0006091': -0.1597813715787436,'ZZZZ0006101': -0.08849453353029052,'ZZZZ0006111': -0.36861839591865514,'ZZZZ0006121': -0.1485522521617286,'ZZZZ0006131': -0.010972392205888375,'ZZZZ0006141': -0.14589749259633997,'ZZZZ0006151': -0.15418415934393556,'ZZZZ0006161': -0.31413295341790787,'ZZZZ0006171': -0.05901440947339298,'ZZZZ0006181': -0.04398448911046628,'ILZZ00000001': -0.624179990224758}

woeDict_mob =   {'ZZZZ0006081':  {(1.0, 1.0): 0.1337,
                                  (2.0, 2.0): -0.7445},
                 'ZZZZ0006091':  {(-1, -1): 0.0314,
                                  (0.0, 8.0): -0.4816,
                                  (9.0, 21.0): -0.2101,
                                  (22.0, 25.0): 0.0314,
                                  (26.0, 27.0): 0.5151,
                                  (28.0, 31.0): 0.7278},
                 'ZZZZ0006101':  {(-1.0, -1.0): 1.769,
                                  (0.0, 0.0): 1.4447,
                                  (0.01, 0.49): -0.7976,
                                  (0.5, 1): -0.9477},
                 'ZZZZ0006111':  {(-3.0, -3.0): 0.614,
                                  (-2.0, -2.0): 1.9759,
                                  (-1.0, -1.0): 1.769,
                                  (0.0, 0.0): 1.0771,
                                  (1.0, 63.0): -0.7087,
                                  (64.0, 147.0): -0.9734,
                                  (148.0, 297.0): -1.2815,
                                  (298.0, 365.0): -1.721},
                 'ZZZZ0006121':  {(-1.0, -1.0): 1.4474,
                                  (0.0, 0.09): 0.9168,
                                  (0.1, 0.5): -1.0421,
                                  (0.51, 1.0): -1.1741},
                 'ZZZZ0006131':  {(-2.0, -2.0): 1.8268,
                                  (-1.0, -1.0): 1.6853,
                                  (0.0, 0.0): -0.6765,
                                  (0.01, 45.0): -2.1138,
                                  (45.01, 60.0): -1.5661,
                                  (60.01, 90.0): -1.4455},
                 'ZZZZ0006141':  {(-2.0, -2.0): 1.8268,
                                  (-1.0, -1.0): 1.6853,
                                  (0.0, 36.0): -0.7236,
                                  (45.0, 90.0): -1.4062},
                 'ZZZZ0006151':  {(-1.0, -1.0): 1.6853,
                                  (0.0, 0.0): 0.6939,
                                  (1.0, 1.0): -0.7112,
                                  (2.0, 2.0): -1.4633,
                                  (3.0, 13.0): -1.9534},
                 'ZZZZ0006161':  {(-1.0, -1.0): 1.769,
                                  (0.0, 0.29): -1.3235,
                                  (0.3, 0.31): -0.883,
                                  (0.32, 0.32): -0.3467,
                                  (0.33, 0.33): 1.2349},
                 'ZZZZ0006171':  {(-2.0, -2.0): 1.6322,
                                  (-1.0, -1.0): 1.5518,
                                  (0.0, 0.32): -1.0574,
                                  (0.33, 0.49): -0.7527,
                                  (0.5, 0.66): -0.1656,
                                  (0.67, 0.85): 0.2106,
                                  (0.86, 1.0): 0.771},
                 'ZZZZ0006181':  {(-1.0, -1.0): 1.2334,
                                  (0.0, 0.29): 1.341,
                                  (0.33, 0.55): -0.049,
                                  (0.56, 0.67): -0.6068,
                                  (0.68, 1.0): -1.0168},
                 'ILZZ00000001':  {(0.0, 0.0): 0.2143,
                                  (1.0, 1.0): -2.4193}}
coefDict_uid = {'intercept': -3.0676230290203503,'ZZZZ0005750': -0.10506855261595828,'ZZZZ0005760': -0.11831697481111125,'ZZZZ0005770': -0.10316132933044499,'ZZZZ0005780': -0.05246890219053679,'ZZZZ0005790': -0.0819628685517761,'ZZZZ0005800': -0.17279445804382654,'ZZZZ0005810': -0.6959872330267275,'ILZZ00000000': -0.5930218738742716,'ZZZZ0005830': -0.22260762358865613}
woeDict_uid =   {'ZZZZ0005750':  {(1.0, 1.0): 0.0926,
                                  (2.0, 2.0): -0.3924},
                 'ZZZZ0005760':  {(-1, -1): -0.2755,
                                  (0, 18): 1.2638,
                                  (19, 25): 0.1998,
                                  (26, 29): -0.1256,
                                  (30, 41): -0.2755,
                                  (42, 48): -0.4706},
                 'ZZZZ0005770':  {(-2.0, -2.0): 0.258,
                                  (-1.0, -1.0): 1.3002,
                                  (0.0, 0.0): 0.873,
                                  (1.0, 1.0): -0.6117,
                                  (2.0, 2.0): -0.8491,
                                  (3.0, 46.0): -0.8832},
                 'ZZZZ0005780':  {(-1.0, -1.0): 0.5999,
                                  (0.0, 0.0): 0.4381,
                                  (1.0, 1.0): -0.2999,
                                  (2.0, 2.0): -0.707,
                                  (3.0, 5.0): -1.0713,
                                  (6.0, 50.0): -1.5322},
                 'ZZZZ0005790':  {(-1.0, -1.0): 0.3929,
                                  (0.0, 0.0): -1.0225,
                                  (1.0, 1.0): -1.2475},
                 'ZZZZ0005800':  {(-2.0, -2.0): 0.2393,
                                  (-1.0, -1.0): 1.4024,
                                  (0.0, 0.22): -0.7599,
                                  (0.23, 0.75): -0.1754,
                                  (1.0, 1.0): 1.526},
                 'ZZZZ0005810':  {(-3.0, -3.0): 0.3228,
                                  (-1.0, -1.0): 2.2894,
                                  (0.0, 0.0): 1.1245,
                                  (1.0, 16.0): -0.3616,
                                  (17.0, 82.0): -0.7237,
                                  (83.0, 298.0): -1.097,
                                  (299.0, 365.0): -1.4782},
                 'ILZZ00000000': {(0.0, 0.0): 0.2219,
                                  (1.0, 1.0): -2.139},
                 'ZZZZ0005830':  {(0.0, 0.0): -0.159,
                                  (1.0, 1.0): 0.5342}}


def AssginWoeFun_mob(value_stats):
    value_woe = {}
    for f in value_stats.keys():
        v = float(value_stats[f])
        dics = woeDict_mob[f]
        key = dics.keys()
        key.sort(reverse=True)
        for j in key:
            if v >= round(float(j[0]),2):
                value_woe[f] = dics[j]
                break
        if f not in value_woe:
            value_woe[f] = dics[(-1.0,-1.0)]
    return value_woe

def AssginWoeFun_uid(value_stats):
    value_woe = {}
    for f in value_stats.keys():
        v = float(value_stats[f])
        dics = woeDict_uid[f]
        key = dics.keys()
        key.sort(reverse=True)
        for j in key:
            if v >= round(float(j[0]),2):
                value_woe[f] = dics[j]
                break
        if f not in value_woe:
            value_woe[f] = dics[(-1.0,-1.0)]
    return value_woe

def AdjustWithBlackGrey(score_uid,score_mob,black,grey):
    if black > 0:
        if score_uid > 530:
            score_uid = 530
        elif score_uid == 0:
            score_uid = 530
        if score_mob > 520:
            score_mob = 520
        elif score_mob == 0:
            score_mob = 520
    else:
        if grey > 0:
            if score_uid > 703:
                score_uid = 703
            elif score_uid == 0:
                score_uid = 703
            if score_mob > 868:
                score_mob = 868
            elif score_mob == 0:
                score_mob = 868
    return score_uid,score_mob

def AdjustWithWeight(score_uid,score_mob):
    if score_uid == 0:
        score = score_mob
    elif score_mob == 0:
        score = score_uid
    else:
        score = int(round(score_uid*0.7+score_mob*0.3,0))
    return score

def BankScoreForUid(x):
    score_uid = 0
    check1 = list(set([x[k] for k in coefDict_uid if k != 'intercept' and k != 'ILZZ00000000']))
    if len(check1) == 1 and float(check1[0]) == -999:
        return score_uid
    value_stats_uid = dict([(k, x[k]) for k in coefDict_uid if k != 'intercept'])
    value_woe = AssginWoeFun_uid(value_stats_uid)
    value_woe['intercept'] = 1
    score = int((600 - 200 / np.log(2) * sum([coefDict_uid[p] * float(value_woe[p]) for p in coefDict_uid])))
    if score < 667:
        score = 667
    if score > 2190:
        score = 2190
    score_uid = int((score-667)*600.0/(2190 - 667) + 300)
    return score_uid

def BankScoreForMob(x):
    score_mob = 0
    check2 = list(set([x[k] for k in coefDict_mob if k != 'intercept' and k != 'ILZZ00000001']))
    if len(check2) == 1 and float(check2[0]) == -999:
        return score_mob
    value_stats_mob = dict([(k, x[k]) for k in coefDict_mob if k != 'intercept'])
    value_woe = AssginWoeFun_mob(value_stats_mob)
    value_woe['intercept'] = 1
    score = int((600 - 200 / np.log(2) * sum([coefDict_mob[p] * float(value_woe[p]) for p in coefDict_mob])))
    if score < 633:
        score = 633
    if score > 2021:
        score = 2021
    score_mob = int((score-633)*600.0/(2021 - 633) + 300)
    return score_mob

def CalWoeAndScore(x):
    '''
    :param x: {k:v}
    :return: score
    '''
    for i in ['ILZZ00000000','ILZZ00000001','ILZZ01000000','ILZZ01000001']:
        if x[i] == -999:
            x[i] = 0
    # 原始分
    # ID
    score_uid = BankScoreForUid(x)
    # mobile
    score_mob = BankScoreForMob(x)
    # 黑灰名单调整
    black = x['ILZZ00000000'] + x['ILZZ00000001']
    grey = x['ILZZ01000000'] + x['ILZZ01000001']
    score_uid, score_mob = AdjustWithBlackGrey(score_uid, score_mob, black, grey)
    # u'加权分数'
    score = AdjustWithWeight(score_uid,score_mob)
    return {'score':score}

def handle(params):
    ret = CalWoeAndScore(params)
    return ret






