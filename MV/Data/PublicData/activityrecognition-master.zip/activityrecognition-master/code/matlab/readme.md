###行为识别特征提取代码
按照[文章](http://ieeexplore.ieee.org/abstract/document/7816862/)中的方法编写了特征提取的代码。
提取的特征一共有27个，如下图所示：
![提取的特征](https://raw.githubusercontent.com/jindongwang/activityrecognition/master/code/featureextraction/features.png)

特征提取代码使用说明见example_usage.m文件。文件夹core是特征提取的核心代码。
